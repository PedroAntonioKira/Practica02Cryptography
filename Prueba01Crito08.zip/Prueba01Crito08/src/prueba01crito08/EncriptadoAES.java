/*
 * Instituto Politecnico Nacional
 * Escuela Superior De Computo.
 * Morales Gonzalez Pedro Antonio.
 * morales.gonzalez.pedroantonio@gmail.com.
 * Criptography.
 * Practica 01.
 */


package prueba01crito08;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

/**
 *
 * @author Morales Gonzalez Pedro Antonio.
 */
public class EncriptadoAES {
    public static void main(String args[]){
        System.out.println("\n\n Hola a todos \n\n");
        
        
        
        try {
            final String claveEncriptacion = "secreto!";            
            final String claveEncriptacion02 = "secreto!";            
            String datosOriginales = "Hola";            
            String datosOriginales02 = "https://medium.com/el-acordeon-del-programador";            
            
            EncriptadorAES encriptador = new EncriptadorAES();
            
            String encriptado = encriptador.encriptar(datosOriginales, claveEncriptacion);
            String desencriptado = encriptador.desencriptar(encriptado, claveEncriptacion02);
            
            System.out.println("Cadena Original: " + datosOriginales);
            System.out.println("Escriptado     : " + encriptado);
            System.out.println("Desencriptado  : " + desencriptado);            
            
        } catch (UnsupportedEncodingException | NoSuchAlgorithmException | InvalidKeyException | NoSuchPaddingException | IllegalBlockSizeException | BadPaddingException ex) {
            Logger.getLogger(EncriptadoAES.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
    
    
    
   
    
    
    
}
