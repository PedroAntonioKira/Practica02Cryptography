/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PracticasCripto_Practica03;

/**
 *
 * @author kenic
 */
public class Archivo {
    
    /*
    *   (1) Estructura de datos del encabezado del archivo de mapa de bits 14 bits
    */
    
    // Tipo de archivo de mapa de bits, debe ser' B '' M 'Dos letras(0-1Bytes) 　 
    int bfType; 
    
    // Tamaño de archivo de mapa de bits en bytes(2-5 Bytes) 　 
    int bfSize; 

    // Las palabras reservadas del archivo de mapa de bits deben ser0(6-7 Bytes) 　　 
    int bfReserved1; 
    
    // Las palabras reservadas del archivo de mapa de bits deben ser0(8-9 Bytes) 　 
    int  bfReserved2; 
    
    // La posición inicial de los datos del mapa de bits, en relación con el mapa de bits(10-13 Bytes) 
    int  bfOffBits; 
    
    
    
    
    /*
    *   (2) Estructura de datos de información de mapa de bits.
    */
    
    // Número de bytes ocupados por esta estructura.(14-17 Bytes) 　
    int Size; 
    
    // Ancho de mapa de bits en píxeles(18-21 Bytes) 　　
    int image_width; 

    // La altura del mapa de bits, en píxeles.(22-25 Bytes) 　
    int image_heigh; 
    
    // El nivel del dispositivo de destino debe ser1(26-27 Bytes) 　　
    int Planes; 

    // El número de bits necesarios para cada píxel debe ser1(Bicolor),(28-29 Byte) 4(16 Color) ， 8(256 Color) O24(// Color verdadero) Uno
    int biBitCount;
    
    // Tipo de compresión de mapa de bits, debe ser0( No comprimido),(30-33 Bytes) 1(BI_RLE8 Tipo de compresión) O// 2(BI_RLE4 Tipo de compresión) Uno
    int biCompression; 
    
    // El tamaño del mapa de bits, en bytes.(34-37 Bytes) 　　
    int SizeImage; 

    // Mapa de bits de resolución horizontal, píxeles por metro(38-41 Bytes) 　　
    int biXPelsPerMeter; 

    // Resolución vertical de mapa de bits, píxeles por metro(42-45 Bytes) 　　
    int biYPelsPerMeter; 
    
    // El número de colores en la tabla de colores realmente utilizados por el mapa de bits(46-49 Bytes) 　　
    int biClrUsed; 
    
    // Número de colores importantes en la visualización de mapa de bits(50-53 Bytes)
    int biClrImportant;
    
    /*
    *   (3) Tabla de colores
    */
    
    
    
}
