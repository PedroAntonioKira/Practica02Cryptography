/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PracticasCripto_Practica03;

/**
 *
 * @author kenic
 */
public class RGBQUAD {
    byte  rgbBlue;// Brillo azul( El rango de valor es0-255) 　　 

    byte  rgbGreen; // Brillo verde( El rango de valor es0-255) 　 

    byte  rgbRed; // Brillo de rojo( El rango de valor es0-255) 　　 

    byte  rgbReserved;// Reservado, debe ser0
}
